var app = angular.module('listaContatos', [])
    .constant('API_URL', 'http://localhost:8000/api/v1/');
//.constant('API_URL','http://www.apilara.ly/');